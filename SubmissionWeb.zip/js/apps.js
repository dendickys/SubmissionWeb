var vm = new Vue ({
    el: '#js',
    data: {
        pesan: 'Nama saya adalah Dicky Saputra, biasa dipanggil Dicky. Halo! Salam kenal.'
    }
})